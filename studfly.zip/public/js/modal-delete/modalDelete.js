
/* const confirmDelete = document.querySelector("#delete-trail-button")
confirmDelete.onclick = toggleConfirmation
function toggleConfirmation(){
    if(document.querySelector("#btn-delete").classList.contains("hidden")){
        document.querySelector("#btn-delete").classList.remove("hidden")
    }else{
        document.querySelector("#btn-delete").classList.add("hidden")
    }
} */