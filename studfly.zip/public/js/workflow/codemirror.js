
/* const textArea = document.getElementById("workflow")


// Inicialize o editor
function CreateCodeEditor(){
var myCodeMirror = CodeMirror.fromTextArea(textArea, {
  lineNumbers: true,
  mode: "javascript"
});
} */