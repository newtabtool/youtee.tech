const notesConteiner = document.getElementById('workflow')


   async function NoteAppend(noteText){
        notesConteiner.textContent = noteText;
    }

  function  saveNote(noteText){

    }

   function clearNote(){

    }


